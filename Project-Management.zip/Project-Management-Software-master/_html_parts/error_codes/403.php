<?php
if(!defined('APPLICATION_LOADED') || !APPLICATION_LOADED) {
    die('No direct script access.');
}
?>
<div id="container">
    <h1>You do not have permission!</h1>
    <h2>403</h2>
</div>